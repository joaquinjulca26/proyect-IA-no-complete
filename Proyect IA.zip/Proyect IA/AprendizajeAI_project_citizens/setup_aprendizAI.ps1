# AprendizAI Setup Script for Windows 11
# Ejecutar este script en PowerShell (ejecutar como administrador recomendado)

Write-Host "==== AprendizAI Setup ====" -ForegroundColor Cyan

# Cambiar a la carpeta del proyecto
Set-Location "C:\AprendizAI"

# 1. Instalar Citizens.jar en el repositorio Maven local (asegúrate de actualizar la ruta si lo moviste)
$mvnCitizens = 'C:\temp\citizens.jar'
if (Test-Path $mvnCitizens) {
    Write-Host "Instalando Citizens.jar en el repo Maven local..." -ForegroundColor Yellow
    mvn install:install-file -Dfile="$mvnCitizens" -DgroupId=net.citizensnpcs -DartifactId=citizens -Dversion=2.0.30-SNAPSHOT -Dpackaging=jar
} else {
    Write-Host "ADVERTENCIA: No se encontró $mvnCitizens. Copia Citizens.jar a C:\temp y vuelve a correr este script." -ForegroundColor Red
}

# 2. Compilar el plugin
Write-Host "Compilando AprendizAI..." -ForegroundColor Yellow
mvn clean package

# 3. Copiar el JAR compilado al servidor Paper
$pluginJar = "C:\AprendizAI\target\AprendizAI-0.2.jar"
$destDir = "C:\paper-server\plugins"
if (Test-Path $pluginJar) {
    Copy-Item $pluginJar -Destination $destDir -Force
    Write-Host "Plugin copiado a $destDir" -ForegroundColor Green
} else {
    Write-Host "ERROR: No se encontró el archivo $pluginJar. Revisa la compilación." -ForegroundColor Red
}

# 4. Recordatorio para el usuario
Write-Host "==== Setup completo ====" -ForegroundColor Cyan
Write-Host "Ahora:" -ForegroundColor Cyan
Write-Host "1) Arranca tu servidor Paper con: java -Xms1G -Xmx2G -jar paper.jar --nogui" -ForegroundColor White
Write-Host "2) Entra a Minecraft y ejecuta: /npc create AprendizBot --type player" -ForegroundColor White
Write-Host "3) En otra ventana de PowerShell: cd C:\AprendizAI ; python .\decisor.py" -ForegroundColor White
Write-Host "4) ¡Listo! Tu AprendizBot debería estar vivo en el mundo." -ForegroundColor Green
