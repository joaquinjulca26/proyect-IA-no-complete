# AprendizAI - Plugin + Decision Service (Minecraft Java)

Este paquete contiene un **plugin base para Spigot/Paper** y un **servicio en Python** que usa la API de OpenAI (ChatGPT) para tomar decisiones. El objetivo: crear un *jugador-IA* (Aprendiz) en Minecraft que tiene memoria en disco (`conciencia.json`) y aprende de eventos y de su mentor.

--- 

## Qué incluye
- `plugin.yml` - definición del plugin.
- `pom.xml` - proyecto Maven para compilar el plugin.
- `src/main/java/...` - código fuente Java (plugin).
- `decisor.py` - servicio Python que llama a OpenAI.
- `requirements.txt` - dependencias Python.
- `conciencia.json` - memoria inicial de ejemplo.
- `README.md` - este archivo.

---

## Requisitos
1. Java 21 (JDK 21)
2. Maven (para compilar el plugin)
3. Minecraft Java Server (PaperMC o Spigot) compatible con la API (ej. 1.20.x)
4. (Opcional) Plugin Citizens si quieres NPCs avanzados.
5. Python 3.10+ y `requests` (pip install -r requirements.txt)
6. Cuenta OpenAI y `OPENAI_API_KEY` como variable de entorno.

---

## Pasos para ejecutar (guía paso a paso para principiantes)

### A) Preparar servidor Minecraft (Paper recommended)
1. Descarga Paper para la versión 1.20.x desde https://papermc.io/downloads (elige la versión).
2. Crea una carpeta `paper-server` y coloca el `paper.jar`.
3. Ejecuta el servidor por primera vez:
   ```
   java -Xms1G -Xmx2G -jar paper.jar --nogui
   ```
   Acepta el EULA editando `eula.txt` y cambiando `eula=false` a `eula=true`. Luego vuelve a ejecutar.

### B) Compilar el plugin Java
1. Abre una terminal en la carpeta del proyecto (donde está `pom.xml`).
2. Ejecuta:
   ```
   mvn clean package
   ```
   Esto generará un archivo JAR en `target/` (por ejemplo `AprendizAI-0.1.jar`).

> Si no sabes usar Maven, dime y te doy instrucciones alternativas para compilar con un IDE (IntelliJ) paso a paso.

### C) Instalar plugin en el servidor
1. Copia `target/AprendizAI-0.1.jar` al folder `plugins/` dentro de tu server `paper-server`.
2. Copia también `conciencia.json` dentro de `paper-server/plugins/AprendizAI/` (la primera vez el plugin lo crea, pero puedes pre-poner uno).
3. (Opcional) Instala **Citizens** plugin si quieres un NPC avatar:
   - Descarga Citizens.jar y ponlo en `plugins/`.
   - En el servidor, crea un NPC con: `/npc create AprendizBot --type player` (asegúrate de permisos).

### D) Ejecutar servidor y verificar plugin
1. Ejecuta el servidor:
   ```
   java -Xms1G -Xmx2G -jar paper.jar --nogui
   ```
2. En la consola del servidor deberías ver logs como `AprendizAI enabled` y `SocketServer listening on 127.0.0.1:5555`.

### E) Preparar y ejecutar el servicio de decisiones (Python)
1. Crea una variable de entorno con tu OpenAI API key:
   - En Windows (PowerShell):
     ```
     setx OPENAI_API_KEY "tu_api_key_aqui"
     ```
     (luego abre una nueva terminal)
   - En macOS/Linux:
     ```
     export OPENAI_API_KEY="tu_api_key_aqui"
     ```
2. Instala dependencias:
   ```
   pip install -r requirements.txt
   ```
3. Ejecuta el servicio:
   ```
   python decisor.py
   ```
   Debería conectarse al plugin y mostrar `Conectado al plugin.`

### F) Probar interacción
- En el juego, cuando interactúes con un aldeano (clic derecho), el plugin enviará un evento al servicio Python.
- El servicio llamará a ChatGPT y te devolverá una acción (por ejemplo `chat` -> el Aprendiz hablará; o `recordGood` -> actualizará `conciencia.json`).

---

## Notas importantes y siguientes pasos
- **Seguridad**: Nunca ponga la API key dentro del código. Manténgala como variable de entorno.
- **Movilidad del NPC**: Para que el Aprendiz se mueva como un jugador, instala Citizens y crea un NPC tipo player. Si quieres que el plugin controle con precisión movimiento/acciones avanzadas necesitaremos integrar la Citizens API (puedo generar ese código si quieres).
- **Mejoras**: prompts mejores, control de rate-limit, autenticación del socket, hacer que el servicio lea `conciencia.json` para usar la memoria directamente.

---

Si quieres, ahora mismo creo:
- El `.jar` del plugin listo (te doy los pasos para compilarlo con Maven).
- Código adicional para integrar con Citizens (control de NPCs).
- Un README paso a paso más guiado para tu sistema operativo (Windows/Mac/Linux).

Dime cuál siguiente paso quieres que haga ahora y lo genero aquí mismo. Si prefieres, te explico cada paso detallado (con capturas de comandos) para hacerlo tú paso a paso. ¡Tú decides!
