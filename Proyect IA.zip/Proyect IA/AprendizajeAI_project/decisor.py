import os
import socket
import json
import threading
import time
import requests

OPENAI_KEY = os.environ.get("OPENAI_API_KEY")
if not OPENAI_KEY:
    print("ERROR: Set OPENAI_API_KEY as environment variable before running.")
    exit(1)

HOST = '127.0.0.1'
PORT = 5555

def call_chatgpt(system_prompt, user_messages):
    url = "https://api.openai.com/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {OPENAI_KEY}",
        "Content-Type": "application/json"
    }
    body = {
        "model": "gpt-5-nano",d
        "messages": [
            {"role":"system","content": system_prompt}
        ] + [{"role":"user","content":m} for m in user_messages],
        "max_tokens": 300,
        "temperature": 0.7
    }
    r = requests.post(url, headers=headers, json=body, timeout=30)
    r.raise_for_status()
    resp = r.json()
    return resp["choices"][0]["message"]["content"]

def handle_event_and_decide(event_json, send_line):
    etype = event_json.get("type")
    system_prompt = (
        "Eres 'Aprendiz', un jugador de Minecraft que aprende valores morales de su mentor. "
        "Recibes eventos del servidor y debes responder con una acción en JSON. "
        "Acciones válidas: {"type":"action","action":"chat","args":{"text":...}}, "
        "{"type":"action","action":"move","args":{"x":..,"y":..,"z":..}}, "
        "{"type":"action","action":"recordGood","args":{"note":"..."}}, "
        "{"type":"action","action":"recordBad","args":{"note":"..."}}. "
        "Devuelve **solo** JSON válido sin texto adicional."
    )
    user_messages = [f"Evento: {json.dumps(event_json)}"]
    try:
        out = call_chatgpt(system_prompt, user_messages)
    except Exception as e:
        print("Error calling ChatGPT:", e)
        # fallback chat action
        action = {"type":"action","action":"chat","args":{"text":"No puedo decidir ahora."}}
        send_line(json.dumps(action))
        return

    # parse JSON response
    try:
        action = json.loads(out)
    except Exception:
        # fallback safe action
        print("Non-JSON response, content:\n", out)
        action = {"type":"action","action":"chat","args":{"text":"No entendí bien la situación."}}
    send_line(json.dumps(action))

def run_client():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        print(f"Conectando a plugin en {HOST}:{PORT}...")
        s.connect((HOST, PORT))
        print("Conectado al plugin.")
        def send_line(line):
            try:
                s.sendall((line + "\n").encode("utf-8"))
            except Exception as e:
                print("Error sending:", e)

        def reader():
            buff = ""
            while True:
                data = s.recv(4096)
                if not data:
                    break
                buff += data.decode("utf-8")
                while "\n" in buff:
                    line, buff = buff.split("\n",1)
                    try:
                        ev = json.loads(line)
                        print("Evento recibido:", ev)
                        threading.Thread(target=handle_event_and_decide, args=(ev, send_line)).start()
                    except Exception as e:
                        print("Invalid event JSON:", e, line)

        reader()

if __name__ == "__main__":
    run_client()
