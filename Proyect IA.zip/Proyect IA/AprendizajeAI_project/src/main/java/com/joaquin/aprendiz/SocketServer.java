package com.joaquin.aprendiz;

import com.google.gson.Gson;
import org.bukkit.Bukkit;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

public class SocketServer extends Thread {
    private final ApprendizPlugin plugin;
    private final int port;
    private ServerSocket serverSocket;
    private volatile boolean running = true;
    private Socket clientSocket;
    private PrintWriter out;
    private BufferedReader in;
    private final LinkedBlockingQueue<String> incoming = new LinkedBlockingQueue<>();
    private final Gson gson = new Gson();

    public SocketServer(ApprendizPlugin plugin, int port) {
        this.plugin = plugin;
        this.port = port;
    }

    public void stopServer() {
        running = false;
        try {
            if (clientSocket != null) clientSocket.close();
            if (serverSocket != null) serverSocket.close();
        } catch (IOException ignored) {}
    }

    @Override
    public void run() {
        try {
            serverSocket = new ServerSocket(port, 1, java.net.InetAddress.getByName("127.0.0.1"));
            plugin.getLogger().info("SocketServer listening on 127.0.0.1:" + port);
            clientSocket = serverSocket.accept();
            plugin.getLogger().info("Decision service connected.");
            out = new PrintWriter(clientSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

            // Thread to read commands from client
            new Thread(() -> {
                String line;
                try {
                    while (running && (line = in.readLine()) != null) {
                        incoming.offer(line);
                    }
                } catch (IOException ignored) {}
            }).start();

            // Main loop: poll incoming commands and apply them on server thread
            while (running) {
                String cmdJson = incoming.poll();
                if (cmdJson != null) {
                    Map cmd = gson.fromJson(cmdJson, Map.class);
                    // Process on main thread
                    Bukkit.getScheduler().runTask(plugin, () -> handleCommand(cmd));
                }
                Thread.sleep(50);
            }
        } catch (Exception e) {
            plugin.getLogger().severe("SocketServer error: " + e.getMessage());
        }
    }

    public void sendEvent(Object ev) {
        if (out != null) {
            String json = gson.toJson(ev);
            out.println(json);
            plugin.getLogger().info("Sent event to decision service: " + json);
        }
    }

    // Example command handler: expects {"type":"action","action":"move","args": {"x":..., "y":..., "z":...}}
    private void handleCommand(Map cmd) {
        if (cmd == null) return;
        String type = (String) cmd.get("type");
        if ("action".equals(type)) {
            String action = (String) cmd.get("action");
            Map args = (Map) cmd.get("args");
            plugin.getLogger().info("Received action: " + action + " args: " + args);
            // Route to NPC controller
            plugin.npcController.executeAction(action, args);
        }
    }
}
