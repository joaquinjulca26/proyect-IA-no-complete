package com.joaquin.aprendiz;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.Map;

public class NPCController {
    private final ApprendizPlugin plugin;
    private String fakePlayerName = "AprendizBot";

    public NPCController(AprendizPlugin plugin) {
        this.plugin = plugin;
    }

    public void executeAction(String action, Map args) {
        switch (action) {
            case "chat":
                String text = (String) args.get("text");
                // Broadcast or whisper
                Bukkit.broadcastMessage("[Aprendiz] " + text);
                // Save memory example
                plugin.memory.addRecuerdo("Dije: " + text);
                break;
            case "move":
                double x = ((Number)args.get("x")).doubleValue();
                double y = ((Number)args.get("y")).doubleValue();
                double z = ((Number)args.get("z")).doubleValue();
                // Simple: teleport the fake player to coords if a player exists with that name
                Player p = Bukkit.getPlayerExact(fakePlayerName);
                if (p != null) {
                    p.teleport(new Location(p.getWorld(), x, y, z));
                } else {
                    // Optionally summon a real NPC or log
                    plugin.getLogger().info("No player named '" + fakePlayerName + "' online to move. coords: " + x + "," + y + "," + z);
                }
                break;
            case "recordGood":
                plugin.memory.incrementStat("ayudas",1);
                plugin.memory.addRecuerdo("Actué correctamente: " + args.getOrDefault("note",""));
                break;
            case "recordBad":
                plugin.memory.incrementStat("daños",1);
                plugin.memory.addRecuerdo("Actué mal: " + args.getOrDefault("note",""));
                break;
            default:
                plugin.getLogger().info("Accion no implementada: " + action);
        }
    }
}
