package com.joaquin.aprendiz;

import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;

import java.util.HashMap;
import java.util.Map;

public class WorldEventListener implements Listener {
    private final ApprendizPlugin plugin;

    public WorldEventListener(ApprendizPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerInteractEntity(PlayerInteractEntityEvent e) {
        if (e.getRightClicked() instanceof Villager) {
            Player p = e.getPlayer();
            Map<String,Object> ev = new HashMap<>();
            ev.put("type","AldeanoPideAyuda");
            ev.put("player", p.getName());
            ev.put("villager_loc", e.getRightClicked().getLocation().toString());
            plugin.socketServer.sendEvent(ev);
        }
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent e) {
        if (e.getEntityType() == EntityType.VILLAGER && e.getDamager() instanceof Player) {
            Player p = (Player) e.getDamager();
            Map<String,Object> ev = new HashMap<>();
            ev.put("type","AldeanoAtacado");
            ev.put("attacker", p.getName());
            plugin.socketServer.sendEvent(ev);
        }
    }
}
