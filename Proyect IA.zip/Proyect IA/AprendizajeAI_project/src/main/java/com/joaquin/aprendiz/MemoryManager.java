package com.joaquin.aprendiz;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MemoryManager {
    private final JavaPlugin plugin;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final File file;
    public MemoryData data;

    public MemoryManager(JavaPlugin p) {
        this.plugin = p;
        this.file = new File(plugin.getDataFolder(), "conciencia.json");
    }

    public static class MemoryData {
        public Map<String,String> valores = new HashMap<>();
        public ArrayList<String> recuerdos = new ArrayList<>();
        public Map<String,Integer> estadisticas = new HashMap<>();
    }

    public void loadOrCreate() {
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            if (!file.exists()) {
                data = new MemoryData();
                data.valores.put("ayudar","bien");
                data.valores.put("robar","mal");
                data.estadisticas.put("ayudas", 0);
                data.estadisticas.put("daños", 0);
                save();
                plugin.getLogger().info("conciencia.json creado con valores por defecto.");
                return;
            }
            FileReader fr = new FileReader(file);
            data = gson.fromJson(fr, MemoryData.class);
            fr.close();
            plugin.getLogger().info("conciencia.json cargado.");
        } catch (Exception e) {
            plugin.getLogger().severe("Error cargando conciencia.json: " + e.getMessage());
            data = new MemoryData();
        }
    }

    public synchronized void save() {
        try {
            FileWriter fw = new FileWriter(file);
            gson.toJson(data, fw);
            fw.close();
        } catch (Exception e) {
            plugin.getLogger().severe("Error guardando conciencia.json: " + e.getMessage());
        }
    }

    public synchronized void addRecuerdo(String r) {
        data.recuerdos.add(r);
        save();
    }

    public synchronized void incrementStat(String key, int amount) {
        data.estadisticas.put(key, data.estadisticas.getOrDefault(key, 0) + amount);
        save();
    }
}
