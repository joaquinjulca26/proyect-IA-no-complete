package com.joaquin.aprendiz;

import com.google.gson.Gson;
import org.bukkit.plugin.java.JavaPlugin;

public class ApprendizPlugin extends JavaPlugin {
    public static ApprendizPlugin INSTANCE;
    public MemoryManager memory;
    public SocketServer socketServer;
    public NPCController npcController;
    public Gson gson = new Gson();

    @Override
    public void onEnable() {
        INSTANCE = this;
        getLogger().info("AprendizAI enabling...");
        // Initialize memory
        memory = new MemoryManager(this);
        memory.loadOrCreate();

        // Initialize NPC controller
        npcController = new NPCController(this);

        // Register events
        getServer().getPluginManager().registerEvents(new WorldEventListener(this), this);

        // Start socket server on a separate thread (localhost only)
        socketServer = new SocketServer(this, 5555);
        socketServer.start();

        getLogger().info("AprendizAI enabled");
    }

    @Override
    public void onDisable() {
        getLogger().info("AprendizAI disabling...");
        if (socketServer != null) socketServer.stopServer();
        memory.save();
    }
}
