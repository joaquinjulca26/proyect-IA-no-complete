package com.joaquin.aprendiz;

import net.citizensnpcs.api.CitizensAPI;
import net.citizensnpcs.api.npc.NPC;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;

import java.util.Map;

public class NPCController {
    private final ApprendizPlugin plugin;
    private String npcName = "AprendizBot";

    public NPCController(ApprendizPlugin plugin) {
        this.plugin = plugin;
    }

    private NPC getAprendizNPC() {
        for (NPC npc : CitizensAPI.getNPCRegistry()) {
            if (npc.getName().equalsIgnoreCase(npcName)) {
                return npc;
            }
        }
        return null;
    }

    public void executeAction(String action, Map args) {
        NPC npc = getAprendizNPC();
        if (npc == null) {
            plugin.getLogger().warning("NPC '" + npcName + "' no encontrado.");
            return;
        }

        switch (action) {
            case "chat":
                String text = (String) args.get("text");
                Bukkit.broadcastMessage("[Aprendiz] " + text);
                plugin.memory.addRecuerdo("Dije: " + text);
                break;

            case "move":
                double x = ((Number) args.get("x")).doubleValue();
                double y = ((Number) args.get("y")).doubleValue();
                double z = ((Number) args.get("z")).doubleValue();
                Location target = new Location(Bukkit.getWorlds().get(0), x, y, z);
                npc.getNavigator().setTarget(target);
                plugin.memory.addRecuerdo("Me moví a " + target);
                break;

            case "attack":
                String targetName = (String) args.get("target");
                LivingEntity target = null;
                for (org.bukkit.entity.Entity ent : npc.getEntity().getNearbyEntities(15, 10, 15)) {
                    if (ent instanceof LivingEntity living) {
                        if (ent.getType().toString().equalsIgnoreCase(targetName)) {
                            target = living;
                            break;
                        }
                    }
                }
                if (target != null) {
                    npc.getNavigator().setTarget(target, true);
                    plugin.memory.addRecuerdo("Ataqué a un " + targetName);
                    Bukkit.broadcastMessage("[Aprendiz] ¡Estoy atacando a un " + targetName + "!");
                } else {
                    plugin.getLogger().info("No encontré enemigo con nombre: " + targetName);
                }
                break;

            case "recordGood":
                plugin.memory.incrementStat("ayudas", 1);
                plugin.memory.addRecuerdo("Actué correctamente: " + args.getOrDefault("note", ""));
                break;

            case "recordBad":
                plugin.memory.incrementStat("daños", 1);
                plugin.memory.addRecuerdo("Actué mal: " + args.getOrDefault("note", ""));
                break;

            default:
                plugin.getLogger().info("Acción no implementada: " + action);
        }
    }
}
