# Servidor Paper + Citizens (Minecraft 1.20.1)

Estructura básica del servidor con carpeta plugins.

👉 Recuerda: los archivos .jar reales NO están incluidos en este paquete.
Debes descargarlos manualmente y colocarlos en las rutas correctas:

- Paper 1.20.1 build 105:
  https://api.papermc.io/v2/projects/paper/versions/1.20.1/builds/105/downloads/paper-1.20.1-105.jar

  Guardar en: paper-server/paper.jar

- Citizens build #3157:
  https://ci.citizensnpcs.co/job/Citizens2/3157/

  Guardar en: paper-server/plugins/Citizens.jar

## 🚀 Instrucciones

1. Extrae esta carpeta en F:\paper-server

2. Coloca los .jar descargados en las rutas indicadas.

3. Abre PowerShell en esa carpeta y ejecuta:
   java -Xms1G -Xmx2G -jar paper.jar --nogui

4. Acepta la licencia en eula.txt y vuelve a ejecutar el comando.

5. Verifica que Citizens aparezca como "Enabled".
