@echo off
cd /d F:\paper_server_package
"C:\Program Files\Java\jdk-21\bin\java.exe" -Xms1G -Xmx2G -jar paper.jar --nogui
pause
